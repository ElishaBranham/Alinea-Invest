self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dc3bb0186e85a67486ade5e13a1c95ee",
    "url": "/webpageCloneTask/index.html"
  },
  {
    "revision": "1ff81dc062783c261121",
    "url": "/webpageCloneTask/static/css/2.8aa5a7f8.chunk.css"
  },
  {
    "revision": "89bd418d2aba4c12bdb0",
    "url": "/webpageCloneTask/static/css/main.08042803.chunk.css"
  },
  {
    "revision": "1ff81dc062783c261121",
    "url": "/webpageCloneTask/static/js/2.5f0ba565.chunk.js"
  },
  {
    "revision": "5ac48c47bb3912b14c2d8de4f56d5ae8",
    "url": "/webpageCloneTask/static/js/2.5f0ba565.chunk.js.LICENSE.txt"
  },
  {
    "revision": "89bd418d2aba4c12bdb0",
    "url": "/webpageCloneTask/static/js/main.e85b83fa.chunk.js"
  },
  {
    "revision": "bf6786e0e2be159f56ea",
    "url": "/webpageCloneTask/static/js/runtime-main.24aadafc.js"
  },
  {
    "revision": "4e1b6caff8c38ef2b09efdc0c636147b",
    "url": "/webpageCloneTask/static/media/credit.4e1b6caf.svg"
  },
  {
    "revision": "f8ff1e774d6319d3ed603edab756e952",
    "url": "/webpageCloneTask/static/media/debit.f8ff1e77.svg"
  },
  {
    "revision": "47c52eb2bfa6cf835a82740e11154900",
    "url": "/webpageCloneTask/static/media/debit2.47c52eb2.svg"
  },
  {
    "revision": "dc0e09c1146ba6ab6f70c052aa572aef",
    "url": "/webpageCloneTask/static/media/debit3.dc0e09c1.svg"
  },
  {
    "revision": "c7bf0efce549c45188843165d58cf86f",
    "url": "/webpageCloneTask/static/media/numberr.c7bf0efc.svg"
  },
  {
    "revision": "3a85fa13fef54d9c08c839e275c80144",
    "url": "/webpageCloneTask/static/media/phonecard.3a85fa13.svg"
  }
]);